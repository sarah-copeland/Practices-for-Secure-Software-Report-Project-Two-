package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.UUID;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String hash(@RequestParam(name = "data", required = false) String data) throws Exception {

        if (data == null || data.isBlank()) {
            data = "SarahCopeland-" + Instant.now() + "-" + UUID.randomUUID();
        }

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));

        StringBuilder hex = new StringBuilder();
        for (byte b : digest) {
            hex.append(String.format("%02x", b));
        }

        return "Algorithm: SHA-256\n"
                + "Input: " + data + "\n"
                + "Checksum: " + hex + "\n";
    }
}
